#include <stdio.h>

#include "list.h"

int main() {
  printf("Tests for linked list implementation\n");
  return 0;
}